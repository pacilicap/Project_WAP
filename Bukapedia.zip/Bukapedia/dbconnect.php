<?php 
// isi nama host, username mysql, dan password mysql anda
$conn = mysqli_connect("localhost","root","","bukapedia");

if(!$conn){
	echo "gagal konek database menn";
} else {
	
};

?>